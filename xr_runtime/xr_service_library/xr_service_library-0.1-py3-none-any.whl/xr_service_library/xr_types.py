# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""
XR Service Type Definitions

This module defines the core data structures used throughout the XR Service system.
It provides type definitions for video frames, audio samples, messages, and metadata
that are exchanged between the XR Service client and server components.

Types:
    Metadata: Contains information about a video frame such as timestamp, pose, and camera parameters
    VideoFrame: Represents a video frame with its associated metadata
    AudioSample: Represents an audio sample with its data and sample rate
    Message: Represents a message with a type and payload for communication

These data structures are serialized and transmitted over the Unix domain socket
connection between the client and server components of the XR Service system.
"""


# Import standard modules
from dataclasses import dataclass

@dataclass
class TypedData:
    def __post_init__(self):
        for (name, field_type) in self.__annotations__.items():
            if not isinstance(self.__dict__[name], field_type):
                current_type = type(self.__dict__[name])
                raise TypeError(f"The field `{name}` was assigned by `{current_type}` instead of `{field_type}`")

@dataclass
class NumpyTensor(TypedData):
    shape: tuple
    dtype: str
    data: bytes

@dataclass
class VideoFrameMetadata(TypedData):
    frame_id: int
    timestamp_ns: int
    pose: NumpyTensor
    orientation: NumpyTensor
    exposure_duration_ns: int
    color_temperature: int
    intrinsics: NumpyTensor

@dataclass
class VideoFrame(TypedData):
    frame: NumpyTensor
    metadata: VideoFrameMetadata

@dataclass
class AudioSample(TypedData):
    audio_data: bytes
    sample_rate: float

@dataclass
class Message(TypedData):
    message_type: str
    payload: str

@dataclass
class Blob(TypedData):
    message_type: str
    payload: bytes
