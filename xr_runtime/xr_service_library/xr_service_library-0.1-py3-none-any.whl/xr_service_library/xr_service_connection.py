# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""
XR Service Client Library

This module provides a client interface for connecting to the XR Service runtime.
It allows applications to:
- Retrieve video frames with associated metadata
- Send and receive audio samples
- Exchange messages with the XR service

The client communicates with the XR Service server through a Unix domain socket
using pickle for serialization of data structures.

Classes:
    PerformanceMetrics: Tracks and reports timing data for client operations
    XRServiceClient: Main client interface for interacting with the XR Service

Usage:
    client = XRServiceClient()
    frame = client.get_latest_frame()
    client.send_audio(audio_sample)
    client.send_message(message)
"""

# Protocol version.
PROTOCOL_VERSION_MAJOR = 0
PROTOCOL_VERSION_MINOR = 1

# Import standard modules
import socket
import sys
import time
from typing import Tuple, Optional, List
from collections import defaultdict, deque

# Import external modules
from loguru import logger

# Import local modules
from .xr_types import VideoFrame, Message, AudioSample, Blob
from .performance_metrics import PerformanceMetrics
from .serialization import MessageReader, MessageBuilder

class XRServiceConnection:
    def __init__(self, socket_path='/tmp/xr_service.sock', log_level='INFO'):
        """Initialize XR Service client
        
        Args:
            socket_path (str): Path to the Unix domain socket
        """
        self._socket_path = socket_path
        self._performance_metrics = PerformanceMetrics()
        self._context = None

        logger.configure(handlers=[{"sink": sys.stderr, "level": log_level}])

    def _validate_protocol_version(self, reader : MessageReader):
        if reader.protocol_version_major != PROTOCOL_VERSION_MAJOR or reader.protocol_version_minor != PROTOCOL_VERSION_MINOR:
            logger.error(f"Server supports protocol version: {reader.protocol_version_major}.{reader.protocol_version_minor}, but client only supports: {PROTOCOL_VERSION_MAJOR}.{PROTOCOL_VERSION_MINOR}")
            raise ValueError(f"Server supports protocol version: {reader.protocol_version_major}.{reader.protocol_version_minor}, but client only supports: {PROTOCOL_VERSION_MAJOR}.{PROTOCOL_VERSION_MINOR}")

    def connect(self) -> bool:
        request = MessageBuilder(PROTOCOL_VERSION_MAJOR, PROTOCOL_VERSION_MINOR)

        # Add an empty context.
        request.append_as_pickle(False)

        # Add the method name.
        request.append_as_raw_bytes(b'initialize_context')

        reader = self._make_request(request.get_serialized())
        
        # Deserialize the context. Context is raw bytes that are used by the server to track the app making requests.
        context = reader.get_next_message()

        # This protocol version just returns True for the context.
        assert(context)

        self._context = context

        logger.info(f"Initialized context")
        return True

    def get_latest_frame(self) -> Optional[VideoFrame]:
        """Get the most recent frame with metadata
        
        Returns:
            VideoFrame: VideoFrame containing 'image' and 'metadata', or None if no frames
        """
        request = self._initialize_message_builder(b'get_latest_frame')
        reader = self._make_request(request.get_serialized())
        
        # Deserialize the frame. First message is the metadata, the second message is the image.
        frame = reader.get_next_message()
        if frame is None:
            # Do not raise an exception here, as it's possible that no frames are available yet.
            logger.warning("No frames available yet")
            return None

        return frame
    
    def get_new_frames(self) -> List[VideoFrame]:
        """Get the new frames that have been added to the buffer since the last call to this method or get_latest_frame.
        
        Returns:
            List[VideoFrame]: List of VideoFrame containing 'image' and 'metadata'
        """
        request = self._initialize_message_builder(b'get_new_frames')
        reader = self._make_request(request.get_serialized())

        frames = []
        while True:
            frame = reader.get_next_message()
            if frame is None:
                logger.debug("No more frames available")
                break
            frames.append(frame)

        return frames
    
    def get_incoming_audio_samples(self) -> List[AudioSample]:
        """Get the entire audio buffer, and flush the buffer.
            
        Returns:
            list: List of dictionaries containing audio data and metadata
        """
        request = self._initialize_message_builder(b'get_incoming_audio_samples')
        reader = self._make_request(request.get_serialized())

        
        samples = []
        while True:
            sample = reader.get_next_message()
            if sample is None:
                logger.debug("No more audio samples available")
                break
            samples.append(sample)
        return samples
    
    def get_buffered_messages(self) -> List[Message]:
        """Get all messages in the message buffer, and flush the buffer.
        
        Returns:
            list: List of dictionaries containing message data and metadata
        """
        request = self._initialize_message_builder(b'get_buffered_messages')
        reader = self._make_request(request.get_serialized())

        
        messages = []
        while True:
            message = reader.get_next_message()
            if message is None:
                logger.debug("No more messages available")
                break
            messages.append(message)
        return messages

    def send_message(self, message: Message):
        """Schedule a message for transmission to the server
        
        Args:
            message (Message): Message to send
        """
        request = self._initialize_message_builder(b'send_message')
        request.append_as_pickle(message)
        reader = self._make_request(request.get_serialized())

        result = reader.get_next_message()
        if not result:
            logger.warning("Failed to send message")
            return False

        return result

    def schedule_audio_transmission(self, audio_sample: AudioSample):
        """Schedule an audio sample for transmission to the server
        
        Args:
            audio_sample (bytes): Audio sample to send
        """
        request = self._initialize_message_builder(b'schedule_audio_transmission')
        request.append_as_pickle(audio_sample)
        reader = self._make_request(request.get_serialized())

        result = reader.get_next_message()
        if not result:
            logger.warning("Failed to schedule audio transmission")
            return False

        return result
    
    def get_buffered_blobs(self) -> List[Blob]:
        """Get all blobs in the blob buffer, and flush the buffer.
        
        Returns:
            list: List of dictionaries containing blob data and metadata
        """
        request = self._initialize_message_builder(b'get_buffered_blobs')   
        reader = self._make_request(request.get_serialized())
        
        blobs = []
        while True:
            blob = reader.get_next_message()
            if blob is None:    
                logger.debug("No more blobs available")
                break
            blobs.append(blob)
        return blobs

    def send_blob(self, blob: Blob):
        """Schedule a blob for transmission to the server
        
        Args:
            blob (Blob): Blob to send
        """
        request = self._initialize_message_builder(b'send_blob')
        request.append_as_pickle(blob)
        reader = self._make_request(request.get_serialized())       

        result = reader.get_next_message()
        if not result:
            logger.warning("Failed to send blob")
            return False

        return result

    def _initialize_message_builder(self, method : bytes) -> MessageBuilder:
        """Make a simple request to the server
        
        Args:
            method (bytes): Method name to call
        """

        if self._context is None:
            logger.error("No context available, please call connect() first")
            raise RuntimeError("No context available, please call connect() first")

        request = MessageBuilder(PROTOCOL_VERSION_MAJOR, PROTOCOL_VERSION_MINOR)
        request.append_as_pickle(self._context)
        request.append_as_raw_bytes(method)

        return request

    def _make_request(self, request_bytes : memoryview) -> MessageReader:
        """Make a request to the Pickle RPC server
        
        Args:
            methodname (str): Method name to call
            args (dict): Additional arguments to send with the request
        Returns:
            Response data from server
        """
        try:
            logger.debug(f"IPC Request with request size: {len(request_bytes)}")
            start_time = time.time()
            # Create socket connection
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect(self._socket_path)
            
            # Send request
            sock.send(request_bytes)
            sock.shutdown(socket.SHUT_WR)
            
            # Receive response
            # Use bytearray for more efficient byte concatenation
            response = bytearray()
            while True:
                data = sock.recv(8 * 1024 * 1024)
                if not data:
                    break
                response.extend(data)

            # Close connection
            sock.close()

            elapsed_time = time.time() - start_time

            # Record performance metrics
            self._performance_metrics.record("raw_ipc_request_size_bytes", len(request_bytes))
            self._performance_metrics.record("raw_ipc_response_size_bytes", len(response))
            self._performance_metrics.record("raw_ipc_request_time_ms", elapsed_time * 1000)
            
            reader = MessageReader(memoryview(response))
            self._validate_protocol_version(reader)

            return reader

        except Exception as e:
            logger.error(f"Error making RPC request: {e}")
            raise
