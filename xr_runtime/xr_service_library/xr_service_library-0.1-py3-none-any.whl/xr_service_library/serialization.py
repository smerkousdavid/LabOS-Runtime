import json
import pickle

# All requests/responses have the following format:
# Byte 0: Protocol version major
# Byte 1: Protocol version minor
# Repeating: Messages
# 
# Message format:
# Byte 0: Message type
# Byte 1: Reserved
# Byte 2: Reserved
# Byte 3: Reserved
# Bytes 4->7: Message length (in bytes, big endian)
# Bytes 8->N: Message data

# Message types:
RESERVED_MESSAGE_TYPE = 0
JSON_UTF8_MESSAGE_TYPE = 1
PICKLE_MESSAGE_TYPE = 2
RAW_BYTES_MESSAGE_TYPE = 3
RESERVED_MESSAGE_TYPE_START = 4
RESERVED_MESSAGE_TYPE_END = 255

class MessageBuilder:
    def __init__(self, protocol_version_major : int, protocol_version_minor : int):
        self._result = bytearray()

        self._result.append(protocol_version_major)
        self._result.append(protocol_version_minor)

    def _add_entry_header(self, message_type : int):
        """Add the header for an entry in the message."""
        self._result.append(message_type)
        # Add the reserved bytes 1->3
        self._result.extend(b'\x00\x00\x00')

    def _append_message_length(self, message_length : int):
        """Update the message length in the header."""
        self._result.append((message_length >> 24) & 0xFF)
        self._result.append((message_length >> 16) & 0xFF)
        self._result.append((message_length >> 8) & 0xFF)
        self._result.append(message_length & 0xFF)

    def append_as_json_utf8(self, message : dict):
        """Append a message as JSON to the result."""
        self._add_entry_header(JSON_UTF8_MESSAGE_TYPE)
        encoded_message = json.dumps(message).encode('utf-8')
        self._append_message_length(len(encoded_message))
        self._result.extend(encoded_message)

    def append_as_pickle(self, message : bytes):
        """Append a message as pickle to the result."""
        self._add_entry_header(PICKLE_MESSAGE_TYPE)
        encoded_message = pickle.dumps(message)
        self._append_message_length(len(encoded_message))
        self._result.extend(encoded_message)

    def append_as_raw_bytes(self, message : bytes):
        """Append a message as raw bytes to the result."""
        self._add_entry_header(RAW_BYTES_MESSAGE_TYPE)
        self._append_message_length(len(message))
        self._result.extend(message)

    def get_serialized(self) -> memoryview:
        """Get the serialized message."""
        return memoryview(self._result)

class MessageReader:
    def __init__(self, data : memoryview):
        self._data = data
        self.protocol_version_major = data[0]
        self.protocol_version_minor = data[1]
        self._offset = 2

    def _get_message_type(self):
        """Get the message type from the data."""
        if self._offset >= len(self._data):
            raise ValueError("Not enough data to get message type")
        return self._data[self._offset]

    def _get_message_length(self):
        """Get the message length from the data."""
        if self._offset + 8 > len(self._data):
            raise ValueError("Not enough data to get message length")
        length = self._data[self._offset + 4] << 24 | self._data[self._offset + 5] << 16 | self._data[self._offset + 6] << 8 | self._data[self._offset + 7]
        return length

    def get_next_message(self):
        """Read a message from the data."""
        # If we have reached the end of the data, return None.
        if self._offset == len(self._data):
            return None

        # If there is only a partial message, raise an error.
        if self._offset + 8 >= len(self._data):
            raise RuntimeError("Not enough data to get message")

        message_type = self._get_message_type()
        message_length = self._get_message_length()
        message = self._data[self._offset + 8:self._offset + 8 + message_length]
        self._offset += 8 + message_length
        if message_type == JSON_UTF8_MESSAGE_TYPE:
            return json.loads(message)
        elif message_type == RAW_BYTES_MESSAGE_TYPE:
            return message
        elif message_type == PICKLE_MESSAGE_TYPE:
            return pickle.loads(message)
        else:
            raise ValueError("Invalid message type")
