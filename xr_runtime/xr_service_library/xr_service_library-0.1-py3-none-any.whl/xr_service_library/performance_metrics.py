# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""
Performance Metrics Module

This module provides functionality for tracking and reporting performance metrics
for the XR Service client operations. It helps monitor the timing of various
method calls to identify potential bottlenecks or performance issues.

Classes:
    PerformanceMetrics: Tracks and reports timing data for client operations

The PerformanceMetrics class maintains a rolling window of timing data for each
method and periodically logs average execution times to help with performance
monitoring and optimization.
"""


# Import standard modules
from collections import defaultdict, deque
import time

# Import external modules
from loguru import logger

class PerformanceMetrics:
    def __init__(self):
        self.timing_data = defaultdict(lambda: deque(maxlen=10))
        self.last_report_time = time.time()
    
    def record(self, method, elapsed_time):
        self.timing_data[method].append(elapsed_time)
        self._report()
    
    def _get_average(self, method):
        return sum(self.timing_data[method]) / len(self.timing_data[method])
    
    def _report(self):
        if time.time() - self.last_report_time > 1.0:
            for method in self.timing_data.keys():
                logger.info(f"{method} - Average: {self._get_average(method)}, Min: {min(self.timing_data[method])}, Max: {max(self.timing_data[method])}")
            self.last_report_time = time.time()