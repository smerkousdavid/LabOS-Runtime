# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

"""
XR Service Library

This package provides the core functionality for interacting with the XR Service system.
It includes client interfaces, data type definitions, and performance monitoring tools.

Components:
    - XRServiceClient: Client interface for connecting to the XR Service
    - VideoFrame, Message, AudioSample, Metadata: Core data structures
    - PerformanceMetrics: Utilities for monitoring and analyzing performance
"""

import sys
sys.path.append('.')

from .xr_types import VideoFrame, Message, AudioSample, VideoFrameMetadata, NumpyTensor, Blob
from .xr_service_connection import XRServiceConnection
from .performance_metrics import PerformanceMetrics
from .serialization import MessageBuilder, MessageReader

__all__ = ['VideoFrame', 'Message', 'AudioSample', 'Blob', 'VideoFrameMetadata', 'NumpyTensor', 'XRServiceConnection', 'PerformanceMetrics', 'MessageBuilder', 'MessageReader']

__version__ = "0.1.0"   
__author__ = "NVIDIA"
__email__ = "info@nvidia.com"
__license__ = "LicenseRef-NvidiaProprietary"
__copyright__ = "Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved."
